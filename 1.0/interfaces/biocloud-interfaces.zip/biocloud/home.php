 <?php 
include_once("base.php");
checkForLogin();

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="shortcut icon" href="/images/favicon.ico" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title> BioCloud </title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script src="js/jquery-1.9.1.min.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script> 
    <script src="http://malsup.github.com/jquery.form.js"></script> 
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
    .nav-pills > li.active > a, .nav-pills > li.active > a:focus {
        color: white;
        background-color: #d02027;
    }

    .nav-pills > li.active > a:hover {
        background-color: #a00e0e;
        color:white;
    }
    
    .jobtd {
        width:70%;
    }

    .run-job {
        border-color: #ddd; 
        background-color: #f5f5f5;
        padding: 5px;
        width: 100%;
    }

    p {
        padding-left: 10px;
        text-align: left;
        margin:0px;
    }
    
    </style>
  </head>


  <body>
    <?php include_once("includes/navbar.php"); ?>

<button id="modalButton" style="display: none" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 id="modalTitle" class="modal-title">Job Name</h4>
        </div>
        <div class="modal-body">
            
        
        <div class="panel panel-default">
        <div style="display:none;"id="panelHead" class="panel-heading">
            
            Job Info/Detail View:
            
        </div>
       
        <div class="panel-body">
            
              <!-- Job Info Table -->
              
             <table id="jobTable" class="table table-striped" style ="display: none; width: 100%;">
                <tr>
                    <td class="jobtd">UUID</td>
                    <td class="jobtd" id="uuid">sdhgfkjsghfkjsgdkfhgsdfhgsd</td>
                </tr>
                <tr>
                    <td  class="jobtd">Completed</td>
                    <td class="jobtd" id="completed">true</td>
                </tr>
                <tr>
                    <td class="jobtd">Error</td>
                    <td class="jobtd" id="error">false</td>
                </tr>
                <tr>
                    <td class="jobtd">Inputs</td>
                    <td class="jobtd" id="inputs">tgdfgdfgdgfdgfdfgdfgdgde</td>
                </tr>
                <tr>
                    <td class="jobtd">Params</td>
                    <td class="jobtd" id="params">dfguhdljghkjdfhgkjhdkfjghdfg</td>
                </tr>
                <tr>
                    <td class="jobtd">Outputs</td>
                    <td class="jobtd" id="outputs">dggdgfgdfgdfgd</td>
                </tr>
                <tr>
                    <td class="jobtd">Started</td>
                    <td class="jobtd" id="started">12312313</td>
                </tr>
                <tr>
                    <td class="jobtd" >Finished</td>
                    <td class="jobtd" id="finished">12367123</td>
                </tr>
            </table>
            
            <!-- Output Table for modal -->
            <table id="outTable" class="table table-striped" style ="display: none; width: 100%;">
                <tr>
                    <td class="jobtd">UUID</td>
                    <td class="jobtd" id="output_uuid">sdhgfkjsghfkjsgdkfhgsdfhgsd</td>
                </tr>
                <tr>
                    <td  class="jobtd">Type</td>
                    <td class="jobtd" id="type">true</td>
                </tr>
            </table>

            <!-- Job Input Form -->
            <div id="jobSelect" style="display: none;" >
                <h5><strong>Input Artifact: command</strong></h5>
                <select id="command" class="form-control">
                    <option>1</option>
                </select>

                <h5><strong>Input Artifact: file</strong></h5>
                <select id="file" class="form-control">
                    <option>1</option>
                </select>

                <h5><strong>Input Parameter: parameter</strong></h5>
                <select id="parameter" class="form-control">
                    <option>1</option>
                </select>

                <h5 style="padding-top:25px;" ><strong>Output Name: visualization</strong></h5>
                <input type="text" class="form-control" placeholder="Name">

                <input id="cancel" type="button" data-dismiss="modal" style="margin-top: 10px;" class="btn btn-danger" value="Cancel" />
                <input id="go" type="button" style="margin-top: 10px; margin-left: 376px" class="btn btn-info" value="Go" />
            </div>

        </div>
        
      </div>
    </div>
        </div>
      </div>
      
    </div>
  </div>
  
  
  
    <div class="container">
     <h2>Analysis Directory</h2>
     <a href="viewFiles.php" <h5 id="directory"> /biocloud/users/<?php echo $_SESSION['name']; ?></h5></a><br><br>
     

    <form id="form" enctype="multipart/form-data" action="handlers/upload.php" method="POST">
    <input type="hidden" id="max" name="MAX_FILE_SIZE" value="1000000" />
    <input id="upload" name="userfile" type="file" /><br>
    <input id="up_btn" type="button" class="btn btn-info" value="Upload File" />
    <label id="up_lbl" for="up_btn"></label>
    </form>

    

    <h4> Avaliable Plugins:</h4>
    

    <div class="panel panel-default">
        <div class="panel-heading">
        
         <button type="button" class="btn btn-default" data-toggle="collapse" data-target="#PanelDiversity">Diversity</button>
         <button type="button" class="btn btn-default" data-toggle="collapse" data-target="#PanelEmperor">Emperor</button>
         <button type="button" class="btn btn-default" data-toggle="collapse" data-target="#PanelFeature">Feature-table</button>
        </div>
        <div class="panel-body collapse" id="PanelDiversity">
           
        </div>
        <div class="panel-body collapse" id="PanelEmperor">
           <h5>Visualizations</h5>
           <button type="button" id="Test-Job" name="Emperor" class="btn run-job" onclick="openSelectModal(id,name);"><p>Test Job</p></button>
        </div>
        <div class="panel-body collapse" id="PanelFeature">
           
        </div>
    </div>


<div class="panel panel-default">
    <div class="panel-heading">
    
    <ul class="nav nav-pills">
        <li id="Active" role="presentation" class="active" onClick="changeJobCate(this)" ><a href="#" onclick="return false">Active Jobs</a></li>
        <li id="Finished" role="presentation" onClick="changeJobCate(this)"><a href="#" onclick="return false">Finished Job</a></li>
        <li id="Failed" role="presentation" onClick="changeJobCate(this)"><a href="#" onclick="return false">Failed Jobs</a></li>
    </ul>
    
    </div>
    
    <div style="display: block" id="activeDIV" class="panel-body">
        <table id="activeTable" style ="border-collapse: collapse;  width: 100%;">
            <tr>
                <th>Action</th>
                <th>Started</th>
                <th>Elapsed</th>
            </tr>
            
            <tr id="noActive" style="display: none">
                <th>No active jobs...</th>
                <th></th>
                <th></th>
            </tr>
            
            
        </table>
    </div>
    
    <div style="display: none" id="finishDIV"  class="panel-body">
        <table id="finishTable" style ="border-collapse: collapse;  width: 100%;">
            <tr>
                <th>Action</th>
                <th>Started</th>
                <th>Finished</th>
            </tr>
            <tr id="noFinish" style="display: none">
                <th>No finished jobs...</th>
                <th></th>
                <th></th>
            </tr>
            
            
        </table>
    </div>
    
    <div style="display: none" id="failDIV"  class="panel-body">
        <table id="failTable" style ="border-collapse: separate;  width: 100%;">
            <tr>
                <th>Action</th>
                <th>Started</th>
                <th>Finished</th>
            </tr>
            <tr id="noFail" style="display: none">
                <th>No failed jobs...</th>
                <th></th>
                <th></th>
            </tr>
          
            
        </table>
    </div>
    
    
</div>

<div class="panel panel-default">
    <div class="panel-heading">
        
        <ul class="nav nav-pills">
            <li id="Art" role="presentation" class="active" onClick="changeOutCate(this)"><a href="#" onclick="return false">Artifacts</a></li>
            <li id="Vis" role="presentation" onClick="changeOutCate(this)"><a href="#" onclick="return false">Visualizations</a></li>
            <li id="Meta" role="presentation" onClick="changeOutCate(this)"><a href="#" onclick="return false">Metadata</a></li>
        </ul>
        
    </div>
   
    
    <div style="display: block" id="artDIV" class="panel-body">
        <table id="artTable" style ="border-collapse: collapse;  width: 100%;">
            <tr>
                <th>Name</th>
                <th>UUID</th>
                <!-- Format of job outputs - visualizations will have the same format as their type -->
                <th>Type</th>
            </tr>
            <tr>
                <th style="display:none">None avaliable...</th>
                <th></th>
                <th></th>
            </tr>
        </table>
    </div>
    
    <div style="display: none" id="visDIV" class="panel-body">
        <table id="visTable" style ="border-collapse: collapse;  width: 100%;">
            <tr>
                <th>Name</th>
                <th>UUID</th>
                <!-- Format of job outputs - visualizations will have the same format as their type -->
                <th>Type</th>
            </tr>
            <tr>
                <th style="display:none">None avaliable...</th>
                <th></th>
                <th></th>
            </tr>
            <tr>
                <td>TestOutputNameV</td>
                <td>TestOutputUUID</td>
                <td>TestOutputFormat</td>
            </tr>
        </table>
    </div>
    
     <div style="display: none" id="metaDIV" class="panel-body">
        <table id="metaTable" style ="border-collapse: collapse;  width: 100%;">
            <tr>
                <th>Name</th>
                <th>UUID</th>
                <!-- Format of job outputs - visualizations will have the same format as their type -->
                <th>Type</th>
            </tr>
            <tr>
                <th style="display:none">None avaliable...</th>
                <th></th>
                <th></th>
            </tr>
            <tr>
                <td>TestOutputNameM</td>
                <td>TestOutputUUID</td>
                <td>TestOutputFormat</td>
            </tr>
        </table>
    </div>
    
  </div>
</div>

    <?php include_once("includes/footer.php"); ?>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    
    <script type="text/javascript">
    
    var jobs = [];
    var outputs = [];
    
        // on window load, user POST data is sent to the jobs.php handler
        // handler returns JSON encoded associative array containing job info which is then parsed
         $(window).load(function() {
            console.log("jquery called");
            $.post("handlers/jobs.php", function(data) { // 'data' will be the string array returned by the jobs handler
                
                try {
                    data = JSON.parse(data);
                    jobs = data;
                    console.log(data);
                } 
                catch (e) {
                }
                // for each element in the 'data' string array (representing indiv. jobs),
                // the elements are added to the appropriate job monitor submenu 
                // based on whether the job is finished, has failed, or has not finished
                for(var i = 0, len = data.length; i < len; i++) {
                    if(data[i].job_finish == null) {
                        $("#activeTable").append( "<tr> <td > <a id='" + i + "' href='#' onClick='openJobModal(id); return false'  rel='noopener noreferrer'>" + data[i].job_action + "</a></td> <td> "  + data[i].job_start +  "</td> <td>"  + sformat(data[i].job_elapsed) + " </td> </tr>");
                    }
                    else if(data[i].job_error == 1) {
                        $("#failTable").append( "<tr> <td> <a id='" + i + "' href='#' onClick='openJobModal(id); return false' rel='noopener noreferrer'>" + data[i].job_action + "</a></td> <td> "  + data[i].job_start +  "</td> <td>"  + data[i].job_finish + " </td> </tr>");
                    } else {
                        $("#finishTable").append( "<tr> <td> <a id='" + i + "' href='#' onClick='openJobModal(id); return false' rel='noopener noreferrer'>" + data[i].job_action + "</a></td> <td> "  + data[i].job_start +  "</td> <td>"  + data[i].job_finish + " </td> </tr>");
                    }
                }
                
            });
            
         });
         
         
         
         
          // on window load, user POST data is sent to the outputs.php handler
        // handler returns JSON encoded associative array containing output info which is then parsed
         $(window).load(function() {
            console.log("jquery called");
            $.post("handlers/outputs.php", function(data) { // 'data' will be the string array returned by the outputs handler
                
                try {
                    data = JSON.parse(data);
                    outputs = data;
                    console.log(data);
                } 
                catch (e) {
                }
                // for each element in the 'data' string array (representing indiv. outputs),
                // the elements are added to the appropriate output submenu 
                // based on whether the output is an artifact, a visualization, or metadata
                for(var i = 0, len = data.length; i < len; i++) {
                    if(data[i].output_type == "Artifact") {
                        $("#artTable").append( "<tr> <td > <a id='" + i + "' href='#' onClick='openOutModal(id); return false'  rel='noopener noreferrer'>" + data[i].output_name + "</a></td> <td> "  + data[i].output_uuid +  "</td> <td>"  + data[i].output_format + " </td> </tr>");
                    }
                    else if(data[i].output_type == "Metadata") {
                        $("#metaTable").append( "<tr> <td > <a id='" + i + "' href='#' onClick='openOutModal(id); return false'  rel='noopener noreferrer'>" + data[i].output_name + "</a></td> <td> "  + data[i].output_uuid +  "</td> <td>"  + data[i].output_format + " </td> </tr>");
                    } else {
                        $("#visTable").append( "<tr> <td > <a id='" + i + "' href='#' onClick='openOutModal(id); return false'  rel='noopener noreferrer'>" + data[i].output_name + "</a></td> <td> "  + data[i].output_uuid +  "</td> <td>"  + data[i].output_format + " </td> </tr>");
                    }
                }
                
            });
            
         });

         // submits file upload form asynchronously through jquery
        $("#up_btn").on("click", function() {
            if(document.getElementById("upload").files[0].size > document.getElementById("max").value) {
               document.getElementById("up_lbl").innerHTML = "Upload failed: file is not valid/too big."; 
            }
            else {
                $('#form').ajaxSubmit(function(data) { 
                    document.getElementById("up_lbl").innerHTML = data;
                });
            }

            window.setTimeout(function(){
                    document.getElementById("up_lbl").innerHTML = "";
                }, 3000);
        });

         //https://forum.jquery.com/topic/converting-seconds-to-dd-hh-mm-ss-format
         function sformat(s) {
              var fm = [
                    Math.floor(s / 60 / 60 / 24), // DAYS
                    Math.floor(s / 60 / 60) % 24, // HOURS
                    Math.floor(s / 60) % 60, // MINUTES
                    s % 60 // SECONDS
              ];
              console.log(fm)
              return $.map(fm, function(v, i) { return ((v < 10) ? '0' : '') + v; }).join(':');
        }
         
        function changeJobCate(elmn){
            
             elmn.className = "active";
             
             var elmnID = elmn.getAttribute('id');
             
             if (elmnID == "Active") {
                 document.getElementById('activeDIV').style.display = "block";
                 
                 document.getElementById('Finished').classList.remove("active");
                 document.getElementById('Failed').classList.remove("active");
                 
                 document.getElementById('finishDIV').style.display = "none";
                 document.getElementById('failDIV').style.display = "none";
             }
              if (elmnID == "Finished") {
                  document.getElementById('finishDIV').style.display = "block";
                  
                 document.getElementById('Active').classList.remove("active");
                 document.getElementById('Failed').classList.remove("active");
                 
                 document.getElementById('activeDIV').style.display = "none";
                 document.getElementById('failDIV').style.display = "none";
             }
              if (elmnID == "Failed") {
                  document.getElementById('failDIV').style.display = "block";
                  
                 document.getElementById('Finished').classList.remove("active");
                 document.getElementById('Active').classList.remove("active");
                 
                 document.getElementById('finishDIV').style.display = "none";
                 document.getElementById('activeDIV').style.display = "none";
             }
             
             
         }
         
         function changeOutCate(elmn){
            
             elmn.className = "active";
             
             var elmnID = elmn.getAttribute('id');
             
             if (elmnID == "Art") {
                 document.getElementById('artDIV').style.display = "block";
                 
                 document.getElementById('Vis').classList.remove("active");
                 document.getElementById('Meta').classList.remove("active");
                 
                 document.getElementById('visDIV').style.display = "none";
                 document.getElementById('metaDIV').style.display = "none";
             }
              if (elmnID == "Vis") {
                  document.getElementById('visDIV').style.display = "block";
                  
                 document.getElementById('Art').classList.remove("active");
                 document.getElementById('Meta').classList.remove("active");
                 
                 document.getElementById('artDIV').style.display = "none";
                 document.getElementById('metaDIV').style.display = "none";
             }
              if (elmnID == "Meta") {
                  document.getElementById('metaDIV').style.display = "block";
                  
                 document.getElementById('Vis').classList.remove("active");
                 document.getElementById('Art').classList.remove("active");
                 
                 document.getElementById('visDIV').style.display = "none";
                 document.getElementById('artDIV').style.display = "none";
             }
             
             
         }
         
         function openJobModal(val) {
             document.getElementById("jobTable").style.display = "block";
             document.getElementById("outTable").style.display = "none";
             document.getElementById("jobSelect").style.display = "none";
             document.getElementById("panelHead").style.display = "block";
             document.getElementById("panelHead").innerHTML = "Job Info:"
             document.getElementById("modalTitle").innerHTML = jobs[val].job_action;
             document.getElementById("uuid").innerHTML = jobs[val].job_uuid;
             document.getElementById("completed").innerHTML = jobs[val].job_finish != null;
             document.getElementById("error").innerHTML = jobs[val].job_error;
             document.getElementById("inputs").innerHTML = jobs[val].job_inputs;
             document.getElementById("params").innerHTML = jobs[val].job_params;
             document.getElementById("outputs").innerHTML = "Placeholder";
             document.getElementById("started").innerHTML = jobs[val].job_start;
             document.getElementById("finished").innerHTML = jobs[val].job_finish;
             $("#modalButton").click();
         }
         
          function openOutModal(val) {
             document.getElementById("jobTable").style.display = "none";
             document.getElementById("outTable").style.display = "block";
             document.getElementById("jobSelect").style.display = "none";
             document.getElementById("panelHead").style.display = "block";
             document.getElementById("panelHead").innerHTML = "Detail View:"
             document.getElementById("modalTitle").innerHTML = outputs[val].output_name;
             document.getElementById("output_uuid").innerHTML = outputs[val].output_uuid;
             document.getElementById("type").innerHTML = outputs[val].output_format;
             $("#modalButton").click();
         }

         function openSelectModal(id, name) {
             document.getElementById("jobSelect").style.display = "block";
             document.getElementById("jobTable").style.display = "none";
             document.getElementById("outTable").style.display = "none";
             document.getElementById("panelHead").style.display = "none";
             document.getElementById("modalTitle").innerHTML = name + ": " + id;
             $("#modalButton").click();
         }
         
         
    </script>


  </body>
</html>