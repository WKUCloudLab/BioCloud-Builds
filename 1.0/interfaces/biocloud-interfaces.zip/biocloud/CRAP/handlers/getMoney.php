<?php

include_once('../base.php');

$errors = '';

if (isset($_GET['userID'])){
  $userID = filter_input(INPUT_GET, 'userID', FILTER_SANITIZE_STRING);


  $prep_stmt = "SELECT  `transactionID` ,  `amount` ,  `timestamp` FROM  `transaction` WHERE  `userID` =  ? ORDER BY `timestamp` DESC" ;
    $stmt = $conn->prepare($prep_stmt);
    $stmt->bind_param('s', $userID);
    $stmt->execute();
    $stmt->store_result();

    $records = [];
    $i = 0;

    while($i < $stmt->num_rows){
      $stmt->bind_result($transactionID,$amount,$timestamp);
      $stmt->fetch();
      $record['transactionID'] = $transactionID;
      $record['amount'] = $amount;
      $record['timestamp'] = $timestamp;
      $records[$i++] = $record;
      if($amount > 0)
        break;
      }
    if(count($records) <= 1){
        echo "You have ".$records[count($records)-1]['amount']." dollars left this paycheck. You are on track to meet your savings goal this period!";
        die();
    }

     $sum = 0;
    $goalValue = (0.05)*$records[count($records)-1]['amount'];
    for ($i = count($records)-1; $i >= 0  ; $i--) {
        $sum += $records[$i]['amount'];

    }
      $start = $records[count($records)-1]['timestamp'];
      $p1['x'] = ($records[count($records)-1]['timestamp'] - $start)/86400;
      $p1['y'] = $records[count($records)-1]['amount'];
      $p2['x'] = ceil(($records[0]['timestamp'] - $start)/86400);
      $p2['y'] = $sum;
      $p3['x'] = 0;
      $p3['y'] = $goalValue;

      $p4['x'] = 1;
      $p4['y'] = $goalValue;





      //SELECT `goal` FROM `accounts` WHERE `userID`= 'euqiL9dZHe43Fqin';
      $prep_stmt = "SELECT `goal` FROM `accounts` WHERE `userID`= ?" ;
      $stmt = $conn->prepare($prep_stmt);
      $stmt->bind_param('s', $userID);
      $stmt->execute();
      $stmt->store_result();
      $stmt->bind_result($goal);
      $stmt->fetch();
      
       $xIntercept = (($p1['x']*$p2['y']-$p1['y']*$p2['x'])*($p3['x']-$p4['x'])-($p1['x']-$p2['x'])*($p3['x']*$p4['y']-$p3['y']*$p4['x']))/(($p1['x']-$p2['x'])*($p3['y']-$p4['y'])-($p1['y']-$p2['y'])*($p3['x']-$p4['x']));

      if ($xIntercept <= $goal) {
        echo "You have ".$p2['y']." dollars left this paycheck. You need to slow down spending. At your current rate, you will miss your savings goal ".ceil($goal-$xIntercept)." days too early.";
      }else{
        echo "You have ".$p2['y']." dollars left this paycheck. You are on track to meet your savings goal this period!";
      }


}else{
  echo "Request failure";
}


?>