<?php

include_once('../base.php');

$errors = '';

if (isset($_GET['userID'])){
  $userID = filter_input(INPUT_GET, 'userID', FILTER_SANITIZE_STRING);

//UPDATE accounts SET balance = balance + 100 WHERE `userID` = "euqiL9dZHe43Fqin";

  $prep_stmt = "SELECT `balance` FROM accounts WHERE `userID`= ?";
  $stmt = $conn->prepare($prep_stmt);
  $stmt->bind_param('s', $userID);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($amount);
  $stmt->fetch();
  // print_r($stmt);
  echo "You have ";
  echo $amount;
  echo " in your account.";

}else{
  echo "FAIL";
}


?>