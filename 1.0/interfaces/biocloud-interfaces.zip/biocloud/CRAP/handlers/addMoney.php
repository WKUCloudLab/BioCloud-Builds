<?php

include_once('../base.php');

$errors = '';
	$userID = filter_input(INPUT_GET, 'userID', FILTER_SANITIZE_STRING);
if(isset($_SESSION['userID'])){
  $_GET['userID'] = $_SESSION['userID'];
  }

 //	FIRST CALCULATE SCORE
	$prep_stmt = "SELECT  `transactionID` ,  `amount` ,  `timestamp` FROM  `transaction` WHERE  `userID` =  ? ORDER BY `timestamp` DESC" ;
    $stmt = $conn->prepare($prep_stmt);
    $stmt->bind_param('s', $userID);
    $stmt->execute();
    $stmt->store_result();

    $records = [];
    $i = 0;

    while($i < $stmt->num_rows){
      $stmt->bind_result($transactionID,$amount,$timestamp);
      $stmt->fetch();
      $record['transactionID'] = $transactionID;
      $record['amount'] = $amount;
      $record['timestamp'] = $timestamp;
      $records[$i++] = $record;
      if($amount > 0)
        break;
    }
    $res_str = "";
    if(count($records) >= 1){
        $sum = 0;
        $goalValue = (0.05)*$records[count($records)-1]['amount'];
        for ($i = count($records)-1; $i >= 0  ; $i--) {
            $sum += $records[$i]['amount'];

        }
      $res_str = $res_str."Your score for the last paycheck period is ".($sum/$goalValue)." with a remaining balance from your last paycheck of ".($sum)." dollars";
    }
//		FINISH CALCULATING SCORE



if (isset($_GET['userID'],$_GET['amount'],$_GET['days'])){
	$userID = filter_input(INPUT_GET, 'userID', FILTER_SANITIZE_STRING);
  if(isset($_SESSION['userID'])){
  $userID = $_SESSION['userID'];
  }
	$amount = filter_input(INPUT_GET, 'amount', FILTER_SANITIZE_STRING);
  $days = filter_input(INPUT_GET, 'days', FILTER_SANITIZE_NUMBER_INT);


//UPDATE accounts SET balance = balance + 100 WHERE `userID` = "euqiL9dZHe43Fqin";

  $prep_stmt = "UPDATE accounts SET balance = balance + ? , goal = ? WHERE `userID` = ?";
  $stmt = $conn->prepare($prep_stmt);
  $stmt->bind_param('sid', $amount,$days,$userID);
  $stmt->execute();
  $stmt->store_result();

  //INSERT INTO `live`.`transaction` (`transactionID`, `userID`, `amount`, `timestamp`) VALUES (NULL, 'euqiL9dZHe43Fqin', '20', '0');
  $timestamp = time();
  $prep_stmt = "INSERT INTO `live`.`transaction` (`transactionID`, `userID`, `amount`, `timestamp`) VALUES (NULL, ?, ?, ?);";
  $stmt = $conn->prepare($prep_stmt);
  $stmt->bind_param('sdi', $userID,$amount,$timestamp);
  $stmt->execute();
  $stmt->store_result();

  $res_str = $res_str."You have successfully deposited ".$amount." dollars into your account";
  echo $res_str;



}else{
	echo "Process failure";
}

?>