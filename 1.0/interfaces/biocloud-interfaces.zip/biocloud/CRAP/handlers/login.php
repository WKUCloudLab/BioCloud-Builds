<?php
include_once('../base.php');

$errors = '';

if (isset($_POST['email'],$_POST['password'])) {

  //Sanitize input
  $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
  $prep_stmt = "SELECT salt FROM accounts WHERE email=? LIMIT 1;";
  $stmt = $conn->prepare($prep_stmt);
  $stmt->bind_param('s', $email);
  $stmt->execute();
  $stmt->store_result();
  if($stmt->num_rows == 0){
    $errors .= 'User does not exist<br><br>';
  }elseif($stmt->num_rows == 1){ 
    $stmt->bind_result($salt);
    $stmt->fetch();
  }else{
    $errors .= 'Two users have same email. Contact Website Admin.<br><br>';
  }



  if(strlen($errors) == 0){
    //hash password
    $hashedPassword = crypt($_POST["password"], '$6$rounds=5000$'.$salt.'$');
    //see if correct
    $prep_stmt = "SELECT `userID`, `firstname`, `lastname`, `email`  FROM `accounts` WHERE `email`=? AND `password`=? LIMIT 1;";
    $stmt = $conn->prepare($prep_stmt);
    $stmt->bind_param('ss', $email,$hashedPassword);
    $stmt->execute();
    $stmt->store_result();
    if($stmt->num_rows == 1){
      $stmt->bind_result($userID,$firstname,$lastname,$email);
      $stmt->fetch();
    }else{
      $errors .= 'Incorrect Password<br><br>';
    }

    if(strlen($errors) == 0){
      $_SESSION['userID'] = $userID; 
      $_SESSION['firstname'] = $firstname;
      $_SESSION['lastname'] = $lastname;
      $_SESSION['email'] = $email;

      $jsresponse = [];
      $jsresponse['userID'] = $userID;
      $jsresponse['success'] = true;
      echo json_encode($jsresponse);
      die();
    }


  }else{
    echo "FAIL";
    echo $errors;
  }



}



?>