<?php
include_once('../base.php');

if (isset($_POST['firstname'],$_POST['lastname'],$_POST['email'], $_POST['password'])) {
   $errors = '';     

    // Sanitize and validate the data passed in
    $firstname = filter_input(INPUT_POST, 'firstname', FILTER_SANITIZE_STRING);
    $lastname = filter_input(INPUT_POST, 'lastname', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    
    //Validate
    $email = filter_var($email, FILTER_VALIDATE_EMAIL);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $errors .= 'The email address you entered is not valid<br><br>';
    }
    if(isAlphaNumSpace($firstname)){
      $errors .= 'Name contains non alphanumeric characters<br><br>';
    }
    if(isAlphaNumSpace($lastname)){
      $errors .= 'Name contains non alphanumeric characters<br><br>';
    }
    $prep_stmt = "SELECT email FROM accounts WHERE email=? LIMIT 1;";
    $stmt = $conn->prepare($prep_stmt);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->store_result();
    if($stmt->num_rows == 1){
      $errors .= 'Email is already registered<br><br>';
    }
    if(strlen($_POST["password"]) < 6){
      $errors .= 'Password too short.<br><br>';
    }

    if(strlen($errors) == 0){
      //Make account
      $randomSalt = generateRandomString();
      $hashedPassword = crypt($_POST["password"], '$6$rounds=5000$'.$randomSalt.'$');

      //uniqueIDFromDB($conn,$table,$column,$length)
      $userID = uniqueIDFromDB($conn,'accounts','userID', 16);


      $prep_stmt = "INSERT INTO `accounts`(`userID`, `firstname`,`lastname`, `email`, `salt`, `password`) VALUES (?,?,?,?,?,?)";
      $stmt = $conn->prepare($prep_stmt);
      $stmt->bind_param('ssssss', $userID,$firstname,$lastname,$email,$randomSalt,$hashedPassword);
      $stmt->execute();
      //header("Location: home.php");
      print_r($stmt);
      echo "success";

    }else{
      echo $errors;
    }
   
 
}else{
  echo "NEED MORE INFO";
  print_r($_POST);
}



?>