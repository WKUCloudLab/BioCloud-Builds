<?php

include_once('../base.php');

$errors = '';

if(isset($_SESSION['userID'])){
  $_GET['userID'] = $_SESSION['userID'];
  }

if (isset($_GET['userID'],$_GET['amount'])){
	$userID = filter_input(INPUT_GET, 'userID', FILTER_SANITIZE_STRING);
  if(isset($_SESSION['userID'])){
    $userID = $_SESSION['userID'];
  }
	$amount = filter_input(INPUT_GET, 'amount', FILTER_SANITIZE_STRING);
  $amount = -$amount;
//UPDATE accounts SET balance = balance + 100 WHERE `userID` = "euqiL9dZHe43Fqin";

  $prep_stmt = "UPDATE accounts SET balance = balance + ? WHERE `userID` = ?";
  $stmt = $conn->prepare($prep_stmt);
  $stmt->bind_param('sd', $amount,$userID);
  $stmt->execute();
  $stmt->store_result();

  //INSERT INTO `live`.`transaction` (`transactionID`, `userID`, `amount`, `timestamp`) VALUES (NULL, 'euqiL9dZHe43Fqin', '20', '0');
  $timestamp = time();
  $prep_stmt = "INSERT INTO `live`.`transaction` (`transactionID`, `userID`, `amount`, `timestamp`) VALUES (NULL, ?, ?, ?);";
  $stmt = $conn->prepare($prep_stmt);
  $stmt->bind_param('sdi', $userID,$amount,$timestamp);
  $stmt->execute();
  $stmt->store_result();


  echo "SUCCESS";




}else{
	echo "FAIL";
}

?>