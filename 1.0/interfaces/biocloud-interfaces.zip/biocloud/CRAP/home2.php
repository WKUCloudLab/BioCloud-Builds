<?php include_once("base.php"); 

if (!isset($_SESSION['userID'])){
  header("Location: index.php");
  die();
}

/*
SELECT  `transactionID` ,  `amount` ,  `timestamp` 
FROM  `transaction` 
WHERE  `userID` =  "euqiL9dZHe43Fqin"
LIMIT 0 , 30
*/
 $prep_stmt = "SELECT  `transactionID` ,  `amount` ,  `timestamp` FROM  `transaction` WHERE  `userID` =  ? ORDER BY `timestamp` DESC" ;
    $stmt = $conn->prepare($prep_stmt);
    $stmt->bind_param('s', $_SESSION['userID']);
    $stmt->execute();
    $stmt->store_result();

    $records = [];
    $i = 0;
    while($i < $stmt->num_rows){
      $stmt->bind_result($transactionID,$amount,$timestamp);
      $stmt->fetch();
      $record['transactionID'] = $transactionID;
      $record['amount'] = $amount;
      $record['timestamp'] = $timestamp;
      $records[$i++] = $record;
      if($amount > 0){
        break;
      }
    }


   


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Hacking the Dayyy awaayyy</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="/css/main.css">
    <!-- Charts -->
    <link rel="stylesheet" type="text/css" href="/css/chartist.min.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>

    <?php include_once("elements/navbar.php"); ?>

    <div class="fullscreen bg1">
    	<br><br>
    	<div class="container">
    		<div class="row">
    			<div class="col-md-12 white-box">
    			<div class="row"><h1 class="text-center">Link Your Bank App</h1></div>
    			<div class="row">
    				<div class="col-md-6"><img src="images/53.png"></div>
    				<div class="col-md-6">
    						<h1>Fifth Third Bank </h1>
    						<p>Fifth Third Bank (5/3 Bank) is a U.S. regional banking corporation, headquartered in Cincinnati, Ohio at Fifth Third Center, and is the principal subsidiary of holding company Fifth Third Bancorp. The company operates under an Ohio charter.</p>
    						<a href="#"><h2>Link Here</h2></a>
					</div>
    			</div>

    			</div>
    		</div>
    	</div>
    	<br><br>
    </div>




    <?php include_once("elements/footer.php"); ?>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/chartist.min.js" type="text/javascript"></script>
    <script type="text/javascript">
  
    </script>



  </body>
</html>
