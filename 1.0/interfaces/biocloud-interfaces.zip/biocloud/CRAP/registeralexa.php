<?php include_once("base.php"); ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Hacking the Dayyy awaayyy</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="/css/main.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>

    <?//php include_once("elements/navbar.php"); ?>

    <div class="fullscreen bg1">
        <br>
        <div class="container">
        <div class="row">
          <div class="col-md-12 white-box">
          	<div id="insert-here"></div>
            <h1>Login</h1>
            <form id="login-form">
               <div class="form-group">
                    <label for="exampleInputEmail1">Email Address</label>
                    <input name="email" type="email" class="form-control" id="exampleInputEmail1" placeholder="Email">
               </div> 
               <div class="form-group">
                    <label for="exampleInputEmail1">Password</label>
                    <input name="password" type="password" class="form-control" id="exampleInputEmail1" placeholder="Password">
               </div>

                <button id="login-btn" type="button" class="btn btn-success" style="width: 100%;">Login</button>
              </form>           
              <br>
          </div>
        </div>

          <br><br>

          <div class="row">
            <div class="col-md-12 white-box">
              <h1>Response</h1>
              <pre><?php print_r($_GET) ?></pre>
            </div>
          </div>
        </div>
   
    </div>




    <?php include_once("elements/footer.php"); ?>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

    <script type="text/javascript">
      function getParameterByName(name, url) {
	    if (!url) url = window.location.href;
	    name = name.replace(/[\[\]]/g, "\\$&");
	    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
	        results = regex.exec(url);
	    if (!results) return null;
	    if (!results[2]) return '';
	    return decodeURIComponent(results[2].replace(/\+/g, " "));
	}

 $( "#login-btn" ).click(function() {

      
      $.ajax(
    {
        url : "handlers/login.php",
        type: "POST",
        data : $("#login-form").serializeArray(),
        success:function(data, textStatus, jqXHR) 
        {
            //data: return data from server
            console.log(data);
            data = JSON.parse(data);
            if(data['success'] == true){
                var client_id = getParameterByName('client_id');
                var state = getParameterByName('state');
                var redirect_uri = getParameterByName('redirect_uri');
                var userID = data['userID'];

                //window.location.href = redirect_uri+'&userID='+userID+'#&state='+state;
                var hreff = redirect_uri+'#&token_type=bearer&access_token='+userID+'&state='+state;
                $("#insert-here").html(`<a href="`+hreff+`">`+hreff+`</a>`);

            }else{
              alert("Error");
              console.log(data);
              console.log(data['success']);
            }


        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
            //if fails      
        }
    });


   });


</script>


    </script>



  </body>
</html>
