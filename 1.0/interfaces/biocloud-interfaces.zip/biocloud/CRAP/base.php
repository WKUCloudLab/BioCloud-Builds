<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
//Where the server is and log in credentials
$servername = "localhost";
$username = "root";
$password = "hacktheplanet!!!";
$dbname = "live";
//Create Connection Object to Database
$conn = new mysqli($servername,$username,$password, $dbname);

//Check Connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$conn->select_db($dbname);

if($conn->error){
	echo "Database Not Found";
	die("Connection failed: " . $conn->error);
}

if(!isset($_SESSION)){
	session_start();
}

function uniqueIDFromDB($conn,$table,$column,$length){
	while(TRUE){
      		$randName = generateRandomStringLen($length);
      		

      		//SHOULD USE PREP STATEMENT. CHANGE THIS IN FUTURE
      		$result = $conn->query("SELECT `".$column."` FROM `".$table."` WHERE `".$column."`= '".$randName."' LIMIT 1");
      		
      		$rowCount =  $result->num_rows;
      		
      		if ($rowCount == 0){
      			break;
      		}
      	}
      	return $randName;
}

function generateRandomStringLen($length) {
	
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


function generateRandomString() {
	$length = 16;
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function isAlphaNum($string){
  if(preg_match('/[^a-z_\-0-9]/i', $string)){
    return true;
  }else{
    return false;
  }
}

function isAlphaNumSpace($string){
  if(preg_match('/[^a-z_ \-0-9]/i', $string)){
    return true;
  }else{
    return false;
  }
}



?>