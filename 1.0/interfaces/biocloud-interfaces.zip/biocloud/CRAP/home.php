<?php include_once("base.php"); 

if (!isset($_SESSION['userID'])){
  header("Location: index.php");
  die();
}

/*
SELECT  `transactionID` ,  `amount` ,  `timestamp` 
FROM  `transaction` 
WHERE  `userID` =  "euqiL9dZHe43Fqin"
LIMIT 0 , 30
*/
 $prep_stmt = "SELECT  `transactionID` ,  `amount` ,  `timestamp` FROM  `transaction` WHERE  `userID` =  ? ORDER BY `timestamp` DESC" ;
    $stmt = $conn->prepare($prep_stmt);
    $stmt->bind_param('s', $_SESSION['userID']);
    $stmt->execute();
    $stmt->store_result();

    $records = [];
    $i = 0;
    while($i < $stmt->num_rows){
      $stmt->bind_result($transactionID,$amount,$timestamp);
      $stmt->fetch();
      $record['transactionID'] = $transactionID;
      $record['amount'] = $amount;
      $record['timestamp'] = $timestamp;
      $records[$i++] = $record;
      if($amount > 0){
        break;
      }
    }


   


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Hacking the Dayyy awaayyy</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="/css/main.css">
    <!-- Charts -->
    <link rel="stylesheet" type="text/css" href="/css/chartist.min.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>

    <?php include_once("elements/navbar.php"); ?>

    <div class="fullscreen bg1">
            
           <br><br><br>
           <div class="container">
            <div class="row">
              <div class="col-md-12 white-box">
                <h1 class="text-center">Dashboard</h1>
                <!-- <div class="col-md-4">
                	<div class="row"><h2 class="text-center">Weekly Spending</h2></div>
                	<div class="row"><div id="ct-chart1" class="ct-perfect-fourth"></div></div>
                </div>

                <div class="col-md-4">
                	<div class="row"><h2 class="text-center">Weekly Budget</h2></div>
                	<div class="row"><div class="ct-minor-sixth" id="ct-chart2"></div></div>
                </div> -->

                <div class="col-md-12">
                	<div class="row"><h2 class="text-center">Weekly Saving Goal</h2></div>
                	<div class="row"><div class="ct-minor-sixth" id="ct-chart3"></div></div>
                </div>

              </div>
            </div>
            <br><br>
            <div class="row">
            	<div class="col-md-12 white-box">
            		<div class="row"><h1 class="text-center">Edit Balance</h1></div>

            		<div class="row">
            			<div class="col-md-6">
            				<h2 class="text-center">Withdraw</h2>
            				<form id="withdraw-form">
            					<div class="form-group col-md-12">
            						<div class="row"><label>Amount</label><br>
            						<input type="text" name="amount" style="width: 100%;"></div><br>
            						<div class="row"><label style="width: 100%;visibility: hidden;">Estimated Days Until Next Pay Check</label><br>
            						<input type="text"  style="width: 100%;visibility: hidden;"></div><br>
            						<div class="row"><button class="btn btn-danger" id="withdraw-btn" type="button" style="width:100%">Widthdraw</button></div>
            					</div>
            				</form>
            			</div>
            			<div class="col-md-6">
            				<h2 class="text-center">Deposit</h2>
            				<form id="deposit-form">
            					<div class="form-group col-md-12">
            						<div class="row"><label>Amount</label><br>
            						<input type="text" name="amount" style="width: 100%;"></div><br>
            						<div class="row"><label>Estimated Days Until Next Pay Check</label><br>
            						<input type="text" name="days" style="width: 100%;"></div><br>
            						<div class="row"><button id="deposit-btn" type="button" class="btn btn-success" style="width:100%">Deposit</button></div>
            					</div>
            				</form>
            			</div>
            		</div>
            	</div>
            </div>
            <br><br>
            <div class="row">
    			<div class="col-md-12 white-box">
    				<h1 class="text-center">Transaction Log</h1>
                    <table class="table">
                        <tr style="font-weight: bold;">
                            <td>Transaction</td>
                            <td>Amount</td>
                            <td>Timestamp</td>
                        </tr>
                    
    				<?php
                    foreach ($records as $key => $record) {
                        echo "<tr>";
                        echo "<td style='width:33.33%'>".$record['transactionID']."</td>";
                        echo "<td style='width:33.33%'>".$record['amount']."</td>";
                        echo "<td style='width:33.33%'>".date("F j, Y, g:i a", $record['timestamp']-3600*4   )."</td>";
                        echo("</tr>");
                    }
                    ?>

                    </table>
                   
    			</div>
            </div>





            </div>

            <br><br>

           
            <br>



   
    </div>




    <?php include_once("elements/footer.php"); ?>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/chartist.min.js" type="text/javascript"></script>
    <script type="text/javascript">
      
      $("#learn-more").click(function(){
        $( "#more-info" ).toggle( "slow", function() {
          // Animation complete.
        });
      })






    var data = {
	  // A labels array that can contain any sort of values
	  labels: ['Sun','Mon', 'Tue', 'Wed', 'Thu', 'Fri','Sat'],
	  // Our series array that contains series objects or in this case series data arrays
	  series: [
	    [15,24, 12, 50, 6, 12,19]
	  ]
	};

	// Create a new line chart object where as first parameter we pass in a selector
	// that is resolving to our chart container element. The Second parameter
	// is the actual data object.
	new Chartist.Line('#ct-chart1', data);
	

	var data = {
	  series: [5, 3, 4]
	};

	var sum = function(a, b) { return a + b };

	new Chartist.Pie('#ct-chart2', data, {
	  labelInterpolationFnc: function(value) {
	    return Math.round(value / data.series.reduce(sum) * 100) + '%';
	  }
	});



	new Chartist.Line('#ct-chart3', {
	  labels: [<?php 
        for ($i = 0; $i < count($records)-1; $i++) {
            echo '"p'.$i.'",';
        }
        echo '"'.(count($records)-1).'"';
       ?>],
	  series: [[<?php 
        $sum = 0;
        $goalValue = (0.05)*$records[count($records)-1]['amount'];
        for ($i = count($records)-1; $i > 0  ; $i--) {
            $sum += $records[$i]['amount'];
            echo '"'.$sum.'",';

        }
        $sum += $records[0]['amount'];
        echo '"'.$sum.'"';
       ?>],[<?php 
       for ($i = count($records)-1; $i > 0  ; $i--) {
            echo '"'.$goalValue.'",';
        }
            echo '"'.$goalValue.'"';
       ?>]]
	}, {
	  fullWidth: true,
	  chartPadding: {
	    right: 40
	  }
	});




    $( "#withdraw-btn" ).click(function() {

      
      $.ajax(
    {
        url : "handlers/subMoney.php",
        type: "GET",
        data : $("#withdraw-form").serializeArray(),
        success:function(data, textStatus, jqXHR) 
        {
            //data: return data from server
            console.log(data);
            if(data=="SUCCESS"){
                location.reload();
            }else{
              alert("Error");
              console.log(data);
            }


        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
            //if fails      
        }
    });


   });






    $( "#deposit-btn" ).click(function() {

      
      $.ajax(
    {
        url : "handlers/addMoney.php",
        type: "GET",
        data : $("#deposit-form").serializeArray(),
        success:function(data, textStatus, jqXHR) 
        {
            //data: return data from server
            // console.log(data);
            // if(data=="SUCCESS"){
                
            // }else{
            //   //alert("Error");
            //   console.log(data);
            // }
            location.reload();

        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
            //if fails      
        }
    });


   });




    </script>



  </body>
</html>
