<?php
	echo("you are very very poor");
?>