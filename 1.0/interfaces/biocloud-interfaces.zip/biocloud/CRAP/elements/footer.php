<footer style="background-color: #414141;color: white">
	<div class="container">
		<div class="col-md-4">
			<h4 class="text-center">Social Media</h4>
			<ul>
				<li>Facebook</li>
				<li>Twitter</li>
				<li>Snapchat</li>
			</ul>
		</div>
		<div class="col-md-4">
			<h4 class="text-center">Legal</h4>
			<ul>
				<li>Facebook</li>
				<li>Twitter</li>
				<li>Snapchat</li>
			</ul>
		</div>
		<div class="col-md-4">
			<h4 class="text-center">Contact Us</h4>
			<ul>
				<li>Facebook</li>
				<li>Twitter</li>
				<li>Snapchat</li>
			</ul>
		</div>
	</div>
</footer>