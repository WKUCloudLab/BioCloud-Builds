<?php

//Logged in Version
if (isset($_SESSION['userID'])):
?>



<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Live Accountable</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav"> 
      </ul>
   
      <ul class="nav navbar-nav navbar-right">
        <!-- <li><a href="#">PUT LOGIN HERE</a></li> -->
        <div style="padding-top: 10px;">
        <form>
          <label>Welcome, <?php echo $_SESSION['firstname']; ?></label>
          <a href="/handlers/logout.php" class="btn btn-danger">Logout</a>
        </form>

        </div>

      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>





<?php 
//Non Logged in Version
else:
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Live Accountable</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav"> 
      </ul>
   
      <ul class="nav navbar-nav navbar-right">
        <!-- <li><a href="#">PUT LOGIN HERE</a></li> -->
        <div style="padding-top: 10px;">
        <form id="login-form">
          <label>Email</label>
          <input type="text" name="email">
          <label>Password</label>
          <input type="password" name="password"> &nbsp;&nbsp;
          <button id="login-btn" type="button" class="btn btn-success">Login</button>
        </form>

        </div>

      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<script type="text/javascript">
  
 $( "#login-btn" ).click(function() {

      
      $.ajax(
    {
        url : "handlers/login.php",
        type: "POST",
        data : $("#login-form").serializeArray(),
        success:function(data, textStatus, jqXHR) 
        {
            //data: return data from server
            console.log(data);
            data = JSON.parse(data);
            if(data['success'] == true){
                window.location.replace("https://liveaccountable.digibara.com/home.php");
            }else{
              alert("Error");
              console.log(data);
              console.log(data['success']);
            }


        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
            //if fails      
        }
    });


   });


</script>



<?php 
endif;
?>
