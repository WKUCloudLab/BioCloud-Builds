<?php include_once("base.php"); 

if (isset($_SESSION['userID'])){
  header("Location: home.php");
  die();
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Live Accountable</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="/css/main.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  
    <?php include_once("elements/navbar.php"); ?>

    <div class="fullscreen bg1">
            
           <br><br><br>
           <div class="container">
            <div class="row">
            
              <div class="col-md-6 col-md-offset-3 white-box">
                <h1 class="text-center">Live Accountable</h1>
                <h4 class="text-center">Helping You Stay Accountable</h4>
                <br>
                <p id="more-info" style="display: none;">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec tincidunt, libero vel elementum blandit, eros mauris tincidunt risus, a consectetur ex lorem at justo. Donec porttitor, ipsum a faucibus pulvinar, erat orci gravida metus, a gravida neque eros at libero. Donec id arcu sed augue gravida placerat. In efficitur ornare mi, nec sodales leo aliquet vel. Nam ac scelerisque mi. Nulla dictum sem vitae lectus vulputate, a ornare enim maximus. Phasellus vitae purus eget nulla ultrices accumsan ut sed elit. Curabitur non erat mollis, ultrices mi sollicitudin, ultricies nulla. Curabitur lorem odio, tristique in ultrices quis, lacinia vel est. Nunc felis turpis, vestibulum at malesuada sed, dignissim quis arcu. Morbi sit amet maximus lorem, sollicitudin efficitur enim. Proin blandit in mauris sed aliquet.
                </p>
                <button type="button" id="learn-more" class="btn btn-success center-block">Learn More<br><i class="fa fa-arrow-down text-center" aria-hidden="true"></i></button>
                <br>

              </div>

            </div>
            </div>

            <br><br>

            <div class="container">
            <div class="row">
            
              <div class="col-md-6 col-md-offset-3 white-box">
                <h1>Sign Up</h1>
                <form id="register-form">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Email Address</label>
                    <input name="email" type="email" class="form-control" id="exampleInputEmail1" placeholder="Email">
                  </div>
                  <div class="form-group">
                    <label>First Name</label>
                    <input name="firstname" type="text" class="form-control" id="exampleInputPassword1" placeholder="First Name">
                  </div>
                  <div class="form-group">
                    <label>Last Name</label>
                    <input name="lastname" type="text" class="form-control" id="exampleInputPassword1" placeholder="Last Name">
                  </div>

                  <div class="form-group">
                    <label>Password</label>
                    <input name="password" type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                  </div>
                  <div class="form-group">
                    <label>Confirm Password</label>
                    <input name="cpassword" type="password" class="form-control" id="exampleInputPassword1" placeholder="Confirm Password">
                  </div>
                  
                  <button type="button" id="register-btn" class="btn btn-success">Submit</button>
                  <br><br>
                </form>
              </div>

            </div>


            </div>
            <br>



   
    </div>




    <?php include_once("elements/footer.php"); ?>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

    <script type="text/javascript">
      
      $("#learn-more").click(function(){
        $( "#more-info" ).toggle( "slow", function() {
          // Animation complete.
        });
      })




    $( "#register-btn" ).click(function() {

      
      $.ajax(
    {
        url : "handlers/register.php",
        type: "POST",
        data : $("#register-form").serializeArray(),
        success:function(data, textStatus, jqXHR) 
        {
            //data: return data from server
            console.log(data);
            if(data=="success"){

            }else{
              alert("Error");
              console.log(data);
            }


        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
            //if fails      
        }
    });


   });





    </script>



  </body>
</html>
