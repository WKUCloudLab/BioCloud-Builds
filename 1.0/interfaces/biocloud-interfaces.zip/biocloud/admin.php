<!-- <?php 

include_once("base.php");
checkForLogin();
adminRedirect(); //added to base.php

$prep_timeframe_sql_statement = "SELECT time_stamp FROM systems;";
$timeframe_sql_statement = $conn->prepare($prep_timeframe_sql_statement);
$timeframe_sql_statement->execute();
$timeframe_sql_statement->store_result();

$total_servers = $timeframe_sql_statement->num_rows;

$servers_online = 0;
$current_time = microtime(true);

for ($i = 0; $i < $total_servers; $i++){
	$timeframe_sql_statement->bind_result($timestamp);
	$timeframe_sql_statement->store_result();
	$timeframe_sql_statement->fetch();
	if (($current_time - $timestamp) < 60){
		$servers_online++;
	}	
}

$prep_stmt = "SELECT * FROM `systems`;";
$stmt = $conn->prepare($prep_stmt);
$host = "host";
$stmt->bind_param('s', $host);
$stmt->execute();
$stmt->store_result();

function percent($number){
    return $number * 100 . '%';
}

?> -->


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>QIIME 2 Cloud</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script src="js/jquery-1.9.1.min.js"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <?php include_once("includes/navbar.php"); ?>

    <div class="container"> 
	
    <div class="col-md-12">
    <h1>System Administration</h1>
    	<div class="panel panel-primary">
    		<div class="panel-heading">System Overview</div>
			  <div class="panel-body">
			    
			    <div class="col-md-3">
			    	<div class="well">
			    		<h3 class="text-center"><i class="fa fa-users big-icons" aria-hidden="true"></i><br>Users Online<br> 10 </h3>
			    	</div>
			    </div>
			    <div class="col-md-3">
			    	<div class="well">
			    		<h3 class="text-center"><i class="fa fa-server big-icons" aria-hidden="true"></i><br>Servers Online<br><?php echo $servers_online.' / '.$total_servers; ?>	</h3>
			    	</div>
			    </div>
			     <div class="col-md-3">
			    	<div class="well">
			    		<h3 id="current-jobs" class="text-center"><i class="fa fa-flask big-icons" aria-hidden="true"></i><br>Current Jobs<br>	</h3>
			    	</div>
			    </div>
			    <div class="col-md-3">
			    	<div class="well">
			    		<!--TODO: no output size to display -->
			    		<h3 class="text-center"><i class="fa fa-hdd-o big-icons" aria-hidden="true"></i><br>Generated Data<br>23 GB	</h3>
			    	</div>
			    </div>
			    <script>
			    	var jobs = [];
			    	
			    	$(window).load(function() {
			            $.post("handlers/jobs.php", function(data) {
			                try {
			                    data = JSON.parse(data);
			                    jobs = data;
			                	console.log(data);
			                    $("#current-jobs").append(data.length); //TODO: current no way to get total number of jobs
			                } catch (e) { console.log(e) }
			                
			    		})
			    	})
			    </script>
			    
		                
			    
			</div>
    	</div>


    	<div class="panel panel-primary">
    		<div class="panel-heading">Architecture Overview</div>
			  <div class="panel-body">
			    

			  <?php
			  $current_time =  microtime (true);
			  for ($i=0; $i < $stmt->num_rows; $i++) { 
				// $stmt->bind_result($uuid, $name, $host, $ram_usage, $ram_total, $cpu_usage, $disk_usage, $disk_total, $time_stamp);
				$stmt->bind_result($uuid, $ram_usage, $ram_total, $cpu_usage, $disk_usage, $disk_total, $time_stamp, $name);
				$stmt->store_result();
			    $stmt->fetch();
			    //      VM
			    // Used for virtual machines
				//	$prep_stmt2 = "SELECT * FROM `systems`;";
				// $stmt2 = $conn->prepare($prep_stmt2);
				// $stmt2->bind_param('s', $uuid);
				// $stmt2->execute();
				// $stmt2->store_result();
				//		VM

			?>


			    <div class="panel panel-primary">
			    	<div class="panel-body">
					    <div class="col-md-3">
					    	<h1 class="text-center"><i <?php if(($current_time - $time_stamp) < 60){ echo 'style="color: green"';}else{ echo 'style="color: red"';}?>  class="fa fa-server huge-icon" aria-hidden="true"></i><br><?php echo $name; ?></h1>
					    </div>
					    <div class="col-md-9">
					    	<!--bytes?/Mb?/Gb?-->
					    	<h3>Memory Usage: <?php echo percent($ram_usage)." of ".$ram_total ?>MB?</h3>
					    	<h3>CPU Usage: <?php echo percent($cpu_usage); ?></h3>
					    	<h3>Disk Usage: <?php echo percent($disk_usage).' of '.$disk_total ?>MB?</h3>
					    </div>
					    <div class="col-md-12">
					    	<!-- VM -->
										<!--Was used for displaying virtual machines of a host machine-->
					    				<?php 
					    		// 		if($stmt2->num_rows != 0){
					    		// 			echo "<h3>Virtual Machines</h3>";
					    		// 		}

					    		// 		for ($j=0; $j < $stmt2->num_rows; $j++) { 
					    		// 			$stmt2->bind_result($vm_uuid, $vm_name, $vm_host, $vm_ram_usage, $vm_ram_total,$vm_cpu_usage, $vm_disk_usage, $vm_disk_total, $vm_time_stamp);
											// $stmt2->store_result();
										 //   $stmt2->fetch();
			    
					    				?>
						    <!--			<div class="well">-->
									    
										<!--	    <div class="col-md-3">-->
										<!--	    	<h3 class="text-center"><i <?php //if(($current_time - $vm_time_stamp) < 60){ echo 'style="color: green"';}else{ echo 'style="color: red"';}?> class="fa fa-server med-icon" aria-hidden="true"></i><br><?php //echo $vm_name; ?></h3>-->
										<!--	    </div>-->
										<!--	    <div class="col-md-9">-->
										<!--	    	<h4>Memory Usage: <?php //echo $vm_ram_usage."/".$vm_ram_total ?> MB</h4>-->
										<!--	    	<h4>CPU Usage: <?php //echo $vm_cpu_usage.'%'; ?></h4>-->
										<!--	    	<h4>Disk Usage: <?php //echo $vm_disk_usage.'/'.$vm_disk_total ?></h4>-->

										<!--	    </div>-->
											    
										<!--<br clear="all" />-->
									 <!--   </div>-->
									  <?php
									  	// }
									  ?>
									    
									<!-- VM -->
					    </div>
					    
				    </div>

			    </div>

<?php } ?>

			<h1>Web Traffic Log</h1>

			<div class="col-md-12 well-xs">
		    	<!--<span style="max-height: 500px;">-->
		    	<pre class="pre-scrollable">
		    		<?php 
						// exec ('cat /var/log/apache2/access.log 2>&1',$output, $return_var);
						
						//cloud9 specific apache log location
						exec('cat ~/lib/apache2/log/access.log 2>&1', $output, $return_var);
						// var_dump($output);
						$output = array_reverse($output, true); //most recent first
						// TODO?: was going to attempt pagination, 
						// instead of outputting 10000+ lines from the logs
						// probably need to encapsulate the exec into a handler first
						
						// $sliced = array_chunk($output, 100);
						// for ($x = 0; $x < sizeof($sliced); $x++) {
						//     print_r($sliced[$x]).'</br>';
						// }
						print_r($output);
					?>
		    	</pre>
			    		
		    	<!--</span>-->
		    	<?php //echo $return_var;?>
			</div>


<?php /*
			    <div class="panel panel-primary">
			    	<div class="panel-body">
					    <div class="col-md-3">
					    	<h1 class="text-center"><i style="color: green" class="fa fa-server huge-icon" aria-hidden="true"></i><br>Server Name</h1>
					    </div>
					    <div class="col-md-9">
					    	<h3>Memory Usage: 200/4064 MB</h3>
					    	<h3>CPU Usage: 40%</h3>
					    	<h3>Disk Usage: 200 / 3063 GB</h3>
					    </div>
					    <div class="col-md-12">
					    	<!-- VM -->
					    	<h3>Virtual Machines</h3>
						    			<div class="well">
									    
											    <div class="col-md-3">
											    	<h3 class="text-center"><i style="color: green" class="fa fa-server med-icon" aria-hidden="true"></i><br>Server Name</h3>
											    </div>
											    <div class="col-md-9">
											    	<h4>Memory Usage: 200/4064 MB</h4>
											    	<h4>CPU Usage: 40%</h4>
											    	<h4>Disk Usage: 200 / 3063 GB</h4>

											    </div>
											    
										<br clear="all" />
									    </div>
									    <div class="well">
									    
											    <div class="col-md-3">
											    	<h3 class="text-center"><i style="color: green" class="fa fa-server med-icon" aria-hidden="true"></i><br>Server Name</h3>
											    </div>
											    <div class="col-md-9">
											    	<h4>Memory Usage: 200/4064 MB</h4>
											    	<h4>CPU Usage: 40%</h4>
											    	<h4>Disk Usage: 200 / 3063 GB</h4>

											    </div>
											    
										<br clear="all" />
									    </div>
									    <div class="well">
									    
											    <div class="col-md-3">
											    	<h3 class="text-center"><i style="color: green" class="fa fa-server med-icon" aria-hidden="true"></i><br>Server Name</h3>
											    </div>
											    <div class="col-md-9">
											    	<h4>Memory Usage: 200/4064 MB</h4>
											    	<h4>CPU Usage: 40%</h4>
											    	<h4>Disk Usage: 200 / 3063 GB</h4>

											    </div>
											    
										<br clear="all" />
									    </div>
									<!-- VM -->
					    </div>
					    
				    </div>
			    </div>


*/ ?>






			</div>
    	</div>

    </div>

    </div>

    <?php include_once("includes/footer.php"); ?>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>


  </body>
</html>