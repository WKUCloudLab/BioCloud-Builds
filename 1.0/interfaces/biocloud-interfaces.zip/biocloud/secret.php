<?php


//Local machine database credentials used for testing
// $servername = "localhost";
// $username = "root";
// $password = "'@@sqlboy@@'";
// $dbname = "qiime_cloud";

?>
