<?php
include_once('../base.php');

if (isset($_POST['email'])){
     $errors = '';
     
     $email = $_POST["email"];
    
    //$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    
    //if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      //$errors .= 'The email address you entered is not valid.<br><br>';
    //}
    $echeck="SELECT email FROM users WHERE email='"."".$email.""."' LIMIT 1;";
    $stmt = $conn->prepare($echeck);
    $stmt->execute();
    $stmt->store_result();
    if($stmt->num_rows == 0){
      $errors .= 'Email does not exist in our records.<br><br>';
    }
     if(strlen($errors) > 0){
         echo $errors;
     }
     else{
         echo "success";
     }
    
    
    
}
?>