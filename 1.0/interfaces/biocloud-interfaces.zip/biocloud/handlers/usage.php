<?php
include_once("../base.php");


if (isset($_GET['cpu'], $_GET['free'], $_GET['totalRam'], $_GET['usedSpace'], $_GET['totalSpace'], $_GET['uuid'])){

	$prep_stmt = "SELECT uuid FROM systems WHERE uuid=? LIMIT 1;";
    $stmt = $conn->prepare($prep_stmt);
    $stmt->bind_param('s', $_GET['uuid']);
    $stmt->execute();
    $stmt->store_result();
    if($stmt->num_rows == 1){
      // if one matching uuid is found, insert to database
    	$time =  microtime (true);
    	$prep_stmt = "UPDATE `systems` SET `ram_usage` =? ,`ram_total`=?, `cpu_usage`=?,`disk_usage`=?,`disk_total`=?,`time_stamp`=? WHERE `systems`.`uuid` = ?;";
	    $stmt = $conn->prepare($prep_stmt);

	    $stmt->bind_param('sssssss', $_GET['free'], $_GET['totalRam'], $_GET['cpu'], $_GET['usedSpace'], $_GET['totalSpace'], $time,$_GET['uuid']);
	    $stmt->execute();

	    //print_r($stmt);

	    $stmt->store_result();

	    echo "success";

    } else {
    	echo "Invalid uuid.";
    	die();
    }



}else {
	echo "Not enough information.";
}


?>