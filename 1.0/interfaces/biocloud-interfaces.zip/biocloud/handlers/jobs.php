<?php
  include_once('../base.php');

  $prep_stmt = "SELECT job_error, job_start, job_finish, job_action, job_uuid, inputs, params FROM jobs WHERE user_uuid='"."".$_SESSION['uuid'].""."';";
  $stmt = $conn->prepare($prep_stmt);
  
  $stmt->execute();
  $stmt->store_result();
  
 if($stmt->num_rows >= 1){ 
    $stmt->bind_result($jobError, $jobStart, $jobFinish, $jobAction, $jobUUID, $jobInputs, $jobParams);
    $myArray = array();
    while($stmt->fetch()) {
        $diffSec = strtotime(date("Y-m-d h:i:s")) - strtotime($jobStart); 
        //$diffTime = date("H:i:s", intval($diffSec));
        $a = array('job_error' => $jobError, 'job_start' => $jobStart, 'job_finish' => $jobFinish, 'job_action' => $jobAction, 'job_elapsed' => $diffSec, 'job_uuid' => $jobUUID, 'job_inputs' => $jobInputs, 'job_params' => $jobParams);
        array_push($myArray, $a);
    }
    //echo strtotime(date("Y-m-d h:i:s"))."\n".strtotime($myArray[0]['job_start'])."\n";
    //echo var_dump($myArray);
    //2017-04-04 21:26:58
    echo json_encode($myArray);
    //echo date("Y-m-d h:i:s");
  }
?>