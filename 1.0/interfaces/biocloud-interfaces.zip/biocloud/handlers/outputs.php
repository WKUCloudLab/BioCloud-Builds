<?php
  include_once('../base.php');

  $prep_stmt = "SELECT output_name, output_type, output_format, output_data, output_uuid FROM outputs WHERE user_uuid='"."".$_SESSION['uuid'].""."';";
  $stmt = $conn->prepare($prep_stmt);
  
  $stmt->execute();
  $stmt->store_result();
  
 if($stmt->num_rows >= 1){ 
    $stmt->bind_result($outputName, $outputType, $outputFormat, $outputData, $outputUUID);
    $myArray = array();
    while($stmt->fetch()) {
        $a = array('output_name' => $outputName, 'output_type' => $outputType, 'output_format' => $outputFormat, 'output_data' => $outputData, 'output_uuid' => $outputUUID);
        array_push($myArray, $a);
    }
    
    echo json_encode($myArray);
    
  }
?>