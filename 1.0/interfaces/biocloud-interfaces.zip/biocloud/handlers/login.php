<?php
include_once('../base.php');

$errors = '';

if (isset($_POST['email'],$_POST['password'])) {

  //Sanitize input
  $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
  $prep_stmt = "SELECT user_salt FROM users WHERE email='"."".$email.""."' LIMIT 1;";
  $stmt = $conn->prepare($prep_stmt);
  //$stmt->bind_param('s', $email);
  $stmt->execute();
  $stmt->store_result();
  if($stmt->num_rows == 0){
    $errors .= 'User does not exist<br><br>';
  }elseif($stmt->num_rows == 1){ 
    $stmt->bind_result($salt);
    $stmt->fetch();
  }else{
      $errors .= 'Two users have same email. Contact Website Admin.<br><br>';
  }



  if(strlen($errors) == 0){
    //hash password
    $hashedPassword = crypt($_POST["password"], '$6$rounds=5000$'.$salt.'$');
    //see if correct
    $prep_stmt = "SELECT `user_uuid`, `user_name`, `email`, `admin` FROM `users` WHERE `email`='"."".$email.""."' AND `user_password`='".$hashedPassword."' LIMIT 1;";
    $stmt = $conn->prepare($prep_stmt);
    //$stmt->bind_param('ss', $email,$hashedPassword);
    $stmt->execute();
    $stmt->store_result();

    if($stmt->num_rows == 1){
      $stmt->bind_result($uuid,$name,$email,$admin);
      $stmt->fetch();
    }else{
      $errors .= 'Incorrect Password.<br><br>';
    }

    if(strlen($errors) == 0){
      $_SESSION['uuid'] = $uuid; 
      $_SESSION['name'] = $name;
      $_SESSION['email'] = $email;
      $_SESSION['admin'] = $admin;

      /*$jsresponse = [];
      $jsresponse['userID'] = $uuid;
      $jsresponse['success'] = 1;*/
      echo true;
      die();
    }


  }else{
    //this is the 'FAIL' I'm talking about in index.php
    //echo "";
    //echo $errors;
  }



}

echo $errors;

?>