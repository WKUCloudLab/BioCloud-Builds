<?php
include_once('../base.php');
include_once('../includes/recaptchalib.php');
	

//Secret key
$privatekey = "6LfYGh8UAAAAANhkZarmZMlqcW8HGEanFyq-crqf";


if (isset($_POST['name'],$_POST['email'], $_POST['password'])) {
   $errors = '';     


   //========================================

    

  $url = 'https://www.google.com/recaptcha/api/siteverify';
	

	$post = [
	    'secret' => $privatekey,
	    'response' => $_POST["g-recaptcha-response"],
	    'remoteip'   => $_SERVER["REMOTE_ADDR"],
	];

	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

	// execute!
	$response = curl_exec($ch);


	// close the connection, release resources used
	curl_close($ch);


	// do anything you want with your response
	//print_r($response);
	$response = json_decode($response);
	//print_r($response);

	if($response->success != true){
		echo "Failed Captcha";
		die();
	}
   //======================================


    // Sanitize and validate the data passed in
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);

    //$lastname = filter_input(INPUT_POST, 'lastname', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    
    //Validate
    $email = filter_var($email, FILTER_VALIDATE_EMAIL);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $errors .= 'The email address you entered is not valid.<br><br>';
    }
    if(isAlphaNumSpace($name)){
      $errors .= 'Display Name may not contain non-alphanumeric characters.<br><br>';
    }
    
    $prep_stmt = "SELECT email FROM users WHERE email='"."".$email.""."' LIMIT 1;";
    $stmt = $conn->prepare($prep_stmt);
    //$stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->store_result();
    if($stmt->num_rows == 1){
      $errors .= 'Email address is already registered.<br><br>';
    }
    if(strlen($_POST["password"]) < 6){
      $errors .= 'Password too short. Passwords must contain at least 6 characters.<br><br>';
    }

    if(strlen($errors) == 0){
      //Make account
      $randomSalt = generateRandomString();
      $hashedPassword = crypt($_POST["password"], '$6$rounds=5000$'.$randomSalt.'$');

      //uniqueIDFromDB($conn,$table,$column,$length)
      $userID = uniqueIDFromDB($conn,'users','user_uuid', 16);
      $admin = 0;
      $prep_stmt = "INSERT INTO `users`(`user_uuid`, `user_name`, `email`, `user_salt`, `user_password`, `admin`) VALUES ('"."".$userID.""."','"."".$name.""."','"."".$email.""."','"."".$randomSalt.""."','"."".$hashedPassword.""."','"."".$admin.""."' )";
      $stmt = $conn->prepare($prep_stmt);
      //$stmt->bind_param('sssss', $userID,$name,$email,$randomSalt,$hashedPassword, $admin);
      $stmt->execute();
      //header("Location: home.php");
      //print_r($stmt);
      
      $_SESSION['uuid'] = $userID; 
      $_SESSION['name'] = $name;
      $_SESSION['email'] = $email;


      echo "success";

    }else{
      echo $errors;
    }
   
 
}else{
  echo "NEED MORE INFO";
  print_r($_POST);
}



?>