
<!-- TODO: add security-->
<?php
include_once("../base.php");
checkForLogin();

$uploaddir = '/biocloud/users/'.$_SESSION['uuid'].'/';
$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);

if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
    echo "File was uploaded successfully.\n";
} else {
    echo "Upload failed: file is not valid/too big.\n";
}


?>