<?php 

include_once("base.php");

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>BioCloud Password Reset</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script src="js/jquery-1.9.1.min.js"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <?php include_once("includes/navbar.php"); ?>

    <div class="container"> 
        <div class="row">
          <div class="col-sm-4"></div>
          <div class="col-sm-4" id="reset">
              <h3>Enter your e-mail address to reset password: </h3>
              <p id="reset-error" style="color: red"></p>
                  <form  id="reset-form" onsubmit="return postt()"   >
                      <div class="form-group">
                        <label for="email"></label>
                        <input type="email" class="form-control" placeholder="Email" id="email">
                      </div>
                       <button type="submit" style="margin:30px" class="btn btn-success center-block" id="submit" >Submit</button>
                  </form>
                   
                 
          </div>
          <div class="col-sm-4" style="display:none;" id="confirm">
              <h3>An email has been sent with instructions on how to reset your password.</h3>
            
          </div>
          <div class="col-sm-4"></div>
        </div>


    </div>

    <?php include_once("includes/footer.php"); ?>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript">
        
         
    function confirmation(){
        document.getElementById("reset").style.display="none";
        document.getElementById("confirm").style.display="block";
        
        return false;
        
             }
             
    function postt(){
        var http = new XMLHttpRequest();
        var x = document.getElementById("email").value;
        var postdata = "email="+x;
        
        http.open("POST", "/handlers/passReset.php", true);
        
        http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        
        http.onreadystatechange = function(){
            if(http.readyState== 4 && http.status == 200) {
                console.log("Response recieved");
                var data=http.responseText;
                console.log(data);
                if(data=="success"){
                    return confirmation();
                }
                else{
                    $("#reset-error").html(data);
                }
            }
        }
        http.send(postdata);
        return false;
    }
    
     
     
    /* $( "#reset-form" ).submit(function( event ) {
       
        var email=$("#email").val();  //value in email
         $.ajax({
             
             url:'handlers/passReset.php',
             type:'POST',
             data : $("#reset-form").serializeArray(),
             success:function(data, textStatus, jqXHR){
               console.log(data);
               
                if(data=="success"){
                           return confirmation();
                        }else{
                          $("#reset-error").html(data);
                          
                        }
             }
             
                    
                             
                    
             
             
         });
         event.preventDefault();
          return false;
     }); */
    </script>
    

  </body>
</html>