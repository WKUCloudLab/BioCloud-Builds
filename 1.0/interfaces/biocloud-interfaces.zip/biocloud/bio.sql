-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2017 at 10:09 PM
-- Server version: 5.5.54-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `c9`
--

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE IF NOT EXISTS `jobs` (
  `job_id` int(4) NOT NULL AUTO_INCREMENT,
  `job_uuid` varchar(300) NOT NULL,
  `job_action` char(100) NOT NULL,
  `job_start` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `job_finish` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `job_error` tinyint(1) NOT NULL,
  `system_uuid` varchar(300) NOT NULL,
  `user_uuid` varchar(25) NOT NULL,
  `inputs` varchar(1000) NOT NULL,
  `params` varchar(1000) NOT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`job_id`, `job_uuid`, `job_action`, `job_start`, `job_finish`, `job_error`, `system_uuid`, `user_uuid`, `inputs`, `params`) VALUES
(1, 'testingUUID', 'testingAction', '2017-03-27 22:41:55', '0000-00-00 00:00:00', 0, 'testingSystemUUID', '1xPyrcVWibjZNy6M', 'testingInputs', 'tetsingParams'),
(2, 'testingUUID2', 'testingAction2', '2017-03-28 21:47:56', NULL, 0, 'testingSystemUUID2', '1xPyrcVWibjZNy6M', 'testingInputs2', 'tetsingParams2'),
(5, 'jobuuid1', 'job1', '2017-04-03 22:08:27', NULL, 0, '', 'cvVc6nNzBHIk1mMh', '', ''),
(6, 'jobuuid2', 'job 2', '2017-04-02 22:08:36', NULL, 0, '', 'cvVc6nNzBHIk1mMh', '', ''),
(7, 'jobuuid3', 'job3', '2017-04-01 22:08:41', NULL, 0, '', 'cvVc6nNzBHIk1mMh', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `outputs`
--

CREATE TABLE IF NOT EXISTS `outputs` (
  `output_id` int(255) NOT NULL AUTO_INCREMENT,
  `output_name` varchar(1000) NOT NULL,
  `output_type` varchar(1000) NOT NULL,
  `output_format` varchar(1000) NOT NULL,
  `output_data` varchar(1000) NOT NULL,
  `output_uuid` varchar(1000) NOT NULL,
  `job_id` int(255) NOT NULL,
  `user_uuid` varchar(25) NOT NULL,
  PRIMARY KEY (`output_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `outputs`
--

INSERT INTO `outputs` (`output_id`, `output_name`, `output_type`, `output_format`, `output_data`, `output_uuid`, `job_id`, `user_uuid`) VALUES
(1, 'outTest', 'Artifact', 'Phylogeny', 'file.test', 'asgsdg4353werrwer4we', 2, '1xPyrcVWibjZNy6M'),
(2, 'outTest2', 'Visualization', 'Visualization', 'file2.test', 'wgfuiygi64fi762h', 1, '1xPyrcVWibjZNy6M'),
(3, 'outTest3', 'Metadata', '???', 'file3.test', 'weiuf7488uij34', 2, '1xPyrcVWibjZNy6M'),
(4, 'outTest3', 'Metadata', '???', 'file3.test', 'weiuf7488uij341', 2, 'cvVc6nNzBHIk1mMh'),
(5, 'outTest3', 'Metadata', '???', 'file3.test', 'weiuf7488uij341', 2, 'cvVc6nNzBHIk1mMh');

-- --------------------------------------------------------

--
-- Table structure for table `systems`
--

CREATE TABLE IF NOT EXISTS `systems` (
  `system_uuid` varchar(255) NOT NULL,
  `ram_usage` decimal(2,2) NOT NULL,
  `ram_total` int(11) NOT NULL,
  `cpu_usage` decimal(2,2) NOT NULL,
  `disk_usage` decimal(2,2) NOT NULL,
  `disk_total` int(11) NOT NULL,
  `time_stamp` date NOT NULL,
  `system_name` varchar(300) NOT NULL,
  PRIMARY KEY (`system_uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `systems`
--

INSERT INTO `systems` (`system_uuid`, `ram_usage`, `ram_total`, `cpu_usage`, `disk_usage`, `disk_total`, `time_stamp`, `system_name`) VALUES
('sys_uuid1', 0.10, 1024, 0.30, 0.40, 1024, '2017-04-18', 'sys_name1'),
('sys_uuid2', 0.50, 2048, 0.40, 0.30, 2048, '2017-04-18', 'sys_name2');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_uuid` char(25) COLLATE utf8_unicode_ci NOT NULL,
  `user_name` char(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `user_password` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `user_salt` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`user_uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_uuid`, `user_name`, `email`, `user_password`, `admin`, `user_salt`) VALUES
('1xPyrcVWibjZNy6M', 'Travis', 'travis.1995@hotmail.com', '$6$rounds=5000$ZzDTetacEIvAcACG$9iyseShqU/cJngIeN4BSN8fEw6Asx7AZhXNVvCX6Ihlw/n3f6qc7neH1crbmvRe1slWrwdmLuDYsrO2GTq4vT0', 0, 'ZzDTetacEIvAcACG'),
('8YYhBOgg0DFhoPGk', 'TrevorDBrown', 'trevor.brown593@topper.wku.edu', '$6$rounds=5000$VmjaKdDEy4PWvh79$tirSYGDzHXDlntHjVxRKdLhATxZuajtDJXBJMnkTLt.Egfr8NQ20dlUN.p0QG1wgCvJgjt4.8tJsqxS4zj27O0', 0, 'VmjaKdDEy4PWvh79'),
('cvVc6nNzBHIk1mMh', 'test123', 'test123@test.com', '$6$rounds=5000$fzoH3kx1fjXXql1G$KhSmEgYG302V1VgoPQ3dkl4dkT9.vHiiRXlZajWG1.5tQkbglT/16g2oDf9DR2zDoDrFcgBOUfc7qyww./7Ql0', 1, 'fzoH3kx1fjXXql1G'),
('eUR1WQuT1jVod02X', 'George', 'apples@gmail.com', '$6$rounds=5000$KVsArxwHMu63K4IW$E2zVEiKHjaYd/WI.ips0F.xA9pjz2H2BzkmQQHRYZusWPKP5fzmplKzQvVEqDgBm1nFxcOkb32wNSsuWQbyF01', 0, 'KVsArxwHMu63K4IW');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
