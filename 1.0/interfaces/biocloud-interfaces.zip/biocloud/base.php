<?php


//Make sure errors are enabled and displaying to HTML
// In Production Turn this off
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


//MYSQL Connection

//Where the server is and log in credentials

//////////////////////////////////////////////////

//Local machine database credentials used for testing


//c9 database stu
$servername = "localhost";
$username = "root";
$password = "biocloud-pass";
$dbname = "c9";
$dbport = 3306;


//Create Connection Object to Database
$conn = new mysqli($servername,$username,$password, $dbname, $dbport);



//Check Connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$conn->select_db($dbname);

if($conn->error){
	echo "Database Not Found";
	die("Connection failed: " . $conn->error);
}

if(!isset($_SESSION)){
	session_start();
}

function uniqueIDFromDB($conn,$table,$column,$length){
	while(TRUE){
      		$randName = generateRandomStringLen($length);
      		

      		//SHOULD USE PREP STATEMENT. CHANGE THIS IN FUTURE
      		$result = $conn->query("SELECT `".$column."` FROM `".$table."` WHERE `".$column."`= '".$randName."' LIMIT 1");
      		
      		$rowCount =  $result->num_rows;
      		
      		if ($rowCount == 0){
      			break;
      		}
      	}
      	return $randName;
}

function generateRandomStringLen($length) {
	
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


function generateRandomString() {
	$length = 16;
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function isAlphaNum($string){
  if(preg_match('/[^a-z_\-0-9]/i', $string)){
    return true;
  }else{
    return false;
  }
}

function isAlphaNumSpace($string){
  if(preg_match('/[^a-z_ \-0-9]/i', $string)){
    return true;
  }else{
    return false;
  }
}

// if user's session id is not set, they are brought back to the login/register index page
function checkForLogin(){
  if(!isset($_SESSION['uuid'])){
      header("Location: ../biocloud/index.php");
  }
}

function checkAdmin(){
  if($_SESSION['admin'] === 0){
    return false;
  }
  return true;
}

function adminRedirect(){
  if(checkAdmin() === false){
    header("Location: ../index.php");
  }
}

function isLoggedIn(){
  return isset($_SESSION['uuid']);
}



?>