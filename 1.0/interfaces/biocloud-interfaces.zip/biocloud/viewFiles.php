 <?php 
include_once("base.php");
checkForLogin();

$files = scandir ("/biocloud/users/".$_SESSION['uuid']) ;

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="shortcut icon" href="/images/favicon.ico" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title> BioCloud </title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script src="js/jquery-1.9.1.min.js"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
    .nav-pills > li.active > a, .nav-pills > li.active > a:focus {
        color: white;
        background-color: #d02027;
    }

    .nav-pills > li.active > a:hover {
        background-color: #a00e0e;
        color:white;
    }
    
    .jobtd {
        border-collapse: collapse;
        border-bottom: 1px solid gray;
        border-top: 1px solid gray;
        width:60%;
    }
    
    </style>
  </head>


  <body>
    <?php include_once("includes/navbar.php"); ?>

    <div class="container">
        <h1>View Files</h1>

        <div class="row">
            <div class="col-md-12">
               <div class="bs-example" data-example-id="striped-table"> 
               <table class="table table-striped table-hover"> 
                    <thead> <tr>  <th>File Name</th> <th>Size</th> </thead> 
                    <tbody id="file-table-body"> 
                        

                    </tbody> 
               </table> </div>
            </div>
        </div>


    </div>
   


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    

    <script type="text/javascript">

        var files =  <?php echo json_encode($files) ?>;

        var html ="";
        for (var i = 0; i < files.length; i++) {
            
            html += `
                    <tr> 
                        <td>`+files[i]+`</td> 
                        <td>100k</td> 
                    </tr> 

            `;
        };

        document.getElementById("file-table-body").innerHTML = html;


    </script>
    


    <?php include_once("includes/footer.php"); ?>
  </body>
</html>