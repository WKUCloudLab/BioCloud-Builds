<?php 
include_once('base.php');

if (!isLoggedIn()){
?>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php"><img src="./images/BioCloudLogo.png" style="position:absolute; top:-5px"></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <form id="login-form" style="padding-top: 10px;">
          <input type="text" name="email" placeholder="Email">
          <input type="password" name="password" placeholder="Password">
          <button class="btn btn-success" style="border-color: rgb(208, 32, 39);background-color: rgb(208, 32, 39);" >Login</button>
        </form>
        <ul style="padding-left: 44%; width: 100%;"><a href="/reset.php">Forgot Password?</a></ul>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<?php
}else{
?>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php"><img src="./images/BioCloudLogo.png" style="position:absolute; top:-6.5px"> </a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <div style="padding-top: 10px;">
        <li style="">
          <span><?php echo "Welcome, ".$_SESSION['name'];?>
          </span>

           <?php if(checkAdmin() === true): ?>
            <a href="admin.php">
              <button class="btn btn-danger" style="margin-left: 10px;">Admin</button>
            </a>
          <?php endif; ?>
          <a href="handlers/logout.php">
            <button class="btn btn-danger" style="margin-left: 10px;">Logout</button>
          </a>
        </li>

        </div>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<?php
}
?>
