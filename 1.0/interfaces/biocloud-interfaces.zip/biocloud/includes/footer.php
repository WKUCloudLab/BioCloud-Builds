<footer id="footer" style="background-color: #d02027;color: white">
	<div class="container">
		<div class="col-md-4">
			<h4 class="text-center">Social Media</h4>
			<p class="text-center" style="font-size: 4em">
				<a style="color: white" href="https://www.facebook.com" aria-label="Facebook"><i class="fa fa-facebook-square" aria-hidden="true"></i></a>
				<a style="color: white" href="https://www.twitter.com" aria-label="Twitter"><i class="fa fa-twitter-square" aria-hidden="true"></i></a>
				<a style="color: white" href="https://www.linkedin.com" aria-label="Linkedin"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a>
				
				
				<!---<i class="fa fa-pinterest-square" aria-hidden="true"></i>
				<i class="fa fa-twitch" aria-hidden="true"></i>
				<i class="fa fa-steam-square" aria-hidden="true"></i>
				<i class="fa fa-facebook-square" aria-hidden="true"></i>
				<i class="fa fa-youtube-square" aria-hidden="true"></i>
				<i class="fa fa-twitter-square" aria-hidden="true"></i>
				<i class="fa fa-usb" aria-hidden="true"></i> --->
			</p>
		</div>
		<div class="col-md-4">
			<h4 class="text-center">Legal</h4>
		</div>
		<div class="col-md-4">
			<h4 class="text-center">Contact Us</h4>
		</div>
	</div>
</footer>


<script type="text/javascript">

 function resizeFooter(){

   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;

   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  
 }

  $(document).ready(resizeFooter);
  $(window).resize(resizeFooter);



</script>