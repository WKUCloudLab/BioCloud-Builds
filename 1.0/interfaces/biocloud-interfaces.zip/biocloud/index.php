
<?php 

include_once("base.php");

if(isset($_SESSION['uuid'])){
    header("Location: home.php");
}

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="shortcut icon" href="./images/favicon.ico" />  
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>BioCloud - Login</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script src="js/jquery-1.9.1.min.js"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <?php include_once("includes/navbar.php"); ?>
    <div id="login-errors"></div>
    <div class="container"> 

    	<div class="row">
    		<div class="col-md-6"> 
    			<img style="width:100%;" src="images/biocloud_large.jpg">
    			<h1 class="text-center"> With </h1>
    			
    			<div class="col-md-offset-3">
    			    <img src="./images/qiime_logo_large.png" height="100%" width="100%" style="position:relative left:-40px"></img>
    				<ul style="font-size: 20 px;padding-left: 10px;"> 
    					<li ><span class="bigger-bullet-text">The QIIME you know and love, powered with the latest cloud technology.</span></li>
    					<li> Your QIIME files, all in one place. </li>
    					<li> Collaborate seamlessly </li> 
    			</div>
    		</div>
    		<div class="col-md-6">
            <div class="well" style="padding: 10px;">

    		  <form id="register-form">
                <h1 class="text-center">Registration</h1>
                <p id="reg-errors" style="color: red"></p>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Display Name</label>
                            <input class="form-control" placeholder="Display name" type="text" name="name" style="width:100%">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" name="email" placeholder="Email" style="width:100%">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                        <label>Password</label>
                        <input type="password" id="password" class="form-control" name="password" placeholder="Password" style="width:100%">
                        </div>    
                    </div>
                    <div class="col-md-6"> 
                        <div class="form-group">
                            <label>Password Confirmation</label>
                            <input type="password" id="cpassword" class="form-control" placeholder="Password" style="width:100%">
                    </div>
                    </div>
                    <div class="col-md-12">
                        <div class="g-recaptcha center-block" data-callback="recaptchaCallback" data-sitekey="6LfYGh8UAAAAABoJdef7nZYHmWE1iA_Ic5zlSR9Y"></div>
                    </div>
                </div>
                    <br>
                    <button id="registerBtn" style="width: 50%;height: 50px ;border-color: rgb(208, 32, 39); background-color: rgb(208, 32, 39);" disabled='disabled' class="btn btn-success center-block">Register</button>
                    <br>
              </form>
    		</div>
            </div>
    	</div>

    </div>

    <?php include_once("includes/footer.php"); ?>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

    <script type="text/javascript">
        
        $( "#register-form" ).submit(function( event ) {

         if($("#password").val() != $("#cpassword").val()){

            $("#reg-errors").html("Passwords don't Match");
            return false;
         }

          $.ajax(
                {
                    url : "handlers/register.php",
                    type: "POST",
                    data : $("#register-form").serializeArray(),
                    success:function(data, textStatus, jqXHR) 
                    {
                        //data: return data from server
                        console.log(data);
                        if(data=="success"){
                            window.location = "home.php";
                        }else{
                          $("#reg-errors").html(data);
                          grecaptcha.reset();
                        }

                    },
                    error: function(jqXHR, textStatus, errorThrown) 
                    {
                        //if fails      
                    }
                });

          event.preventDefault();
          return false;
        });

        $( "#login-form" ).submit(function( event ) {
          $.ajax(
                {
                    url : "handlers/login.php",
                    type: "POST",
                    data : $("#login-form").serializeArray(),
                    success:function(data, textStatus, jqXHR) 
                    {
                        //data: return data from server
                        console.log('test' + ' ' + data);
                            
                        if(data.includes('User does not exist') || data.includes('Incorrect Password')) {
                            //$("#login-errors").html('<div id="login-error" class="alert alert-danger"><strong>Failed Login!</strong> Email and Password combination do not match our records.</div>');
                            $("#login-errors").html('<div id="login-error" class="alert alert-danger"><strong>Failed Login!</strong> ' + data + '</div>');
                        }
                        else {
                            window.location = "home.php";
                        }

                        window.setTimeout(function(){
                            $("#login-error").fadeOut();
                        }, 3000);
                    },
                    //I don't think this will ever be called the way the is structured?
                    error: function(jqXHR, textStatus, errorThrown) {
                        //if fails      
                    }
                });
          event.preventDefault();
          return false;
        });

        //Enable Button After Captcha Callback
        function recaptchaCallback() {
            $('#registerBtn').removeAttr('disabled');
        };

    </script>

  </body>
</html>